package com.example.android.mytodoapp.tasks

enum class TasksFilterType {
    ALL_TASKS,
    ACTIVE_TASKS,
    COMPLETED_TASKS,
    DELETED_TASKS,
    HISTORY,
    CANCELED
}