package com.example.android.mytodoapp.statistics

import com.example.android.mytodoapp.BasePresenter
import com.example.android.mytodoapp.BaseView

interface StatisticsContract {
    interface View : BaseView<Presenter> {
        val isActive: Boolean

        fun setProgressIndicator(active: Boolean)

        fun showStatistics(numberOfIncompleteTasks: Int, numberOfCompletedTasks: Int)

        fun showLoadingStatisticsError()
    }
    interface Presenter : BasePresenter
}