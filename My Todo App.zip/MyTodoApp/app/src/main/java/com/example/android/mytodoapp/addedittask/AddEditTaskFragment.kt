package com.example.android.mytodoapp.addedittask

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import android.widget.TextView
import android.widget.TimePicker
import androidx.fragment.app.Fragment
import com.example.android.mytodoapp.R
import com.example.android.mytodoapp.util.showSnackBar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.*

class AddEditTaskFragment : Fragment(), AddEditTaskContract.View,
    DatePickerDialog.OnDateSetListener,
    TimePickerDialog.OnTimeSetListener {
    lateinit var textView: TextView
    lateinit var calendar: Calendar
    lateinit var date: Date
    lateinit var today: String
    lateinit var clock: String

    var day = 0
    var month: Int = 0
    var year: Int = 0
    var hour: Int = 0
    var minute: Int = 0
    var myDay = 0
    var myMonth: Int = 0
    var myYear: Int = 0
    var myHour: Int = 0
    var myMinute: Int = 0
    override lateinit var presenter: AddEditTaskContract.Presenter
    override var isActive = false
        get() = isAdded

    private lateinit var title: TextView
    private lateinit var description: TextView
    private lateinit var time: TextView
    private lateinit var hashTag: TextView


    override fun onResume() {
        super.onResume()
        presenter.start()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        activity?.findViewById<FloatingActionButton>(R.id.fab_edit_task_done)?.apply {
            setImageResource(R.drawable.ic_done)
            setOnClickListener {
                presenter.saveTask(
                    title.text.toString(),
                    description.text.toString(),
                    date,
                    today,
                    clock,
                    hashTag.text.toString()
                )
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.addtask_frag, container, false)
        with(root) {
            title = findViewById(R.id.add_task_title)
            description = findViewById(R.id.add_task_description)
            time = findViewById(R.id.textDate)
            hashTag = findViewById(R.id.add_task_hash_tag)

            textView = findViewById(R.id.textDate)

        }
        textView.setOnClickListener {
            val calendar: Calendar = Calendar.getInstance()
            day = calendar.get(Calendar.DAY_OF_MONTH)
            month = calendar.get(Calendar.MONTH)
            year = calendar.get(Calendar.YEAR)
            val datePickerDialog =
                DatePickerDialog(context!!, this, year, month, day)
            datePickerDialog.show()
        }
        setHasOptionsMenu(true)
        return root
    }

    override fun showEmptyTaskError() {
        title.showSnackBar(getString(R.string.empty_task_message), Snackbar.LENGTH_LONG)
    }

    override fun showTasksList() {
        activity?.apply {
            setResult(Activity.RESULT_OK)
            finish()
        }
    }

    override fun setTitle(title: String) {
        this.title.text = title
    }

    override fun setHashTag(hashTag: String) {
        this.hashTag.text = hashTag
    }

    override fun setDescription(description: String) {
        this.description.text = description
    }
    override fun setTime(time: Date?,today:String,clock: String) {
        this.time.text = time.toString()
        date=time!!
        this.today=today
        this.clock=clock

    }



    companion object {
        const val ARGUMENT_EDIT_TASK_ID = "EDIT_TASK_ID"

        fun newInstance(taskId: String?) =
            AddEditTaskFragment().apply {
                arguments = Bundle().apply {
                    putString(AddEditTaskFragment.ARGUMENT_EDIT_TASK_ID, taskId)
                }
            }
    }

    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        myDay = dayOfMonth
        myYear = year
        myMonth = month
        calendar = Calendar.getInstance()
        hour = calendar.get(Calendar.HOUR)
        minute = calendar.get(Calendar.MINUTE)
        val timePickerDialog = TimePickerDialog(context, this, hour, minute,
            DateFormat.is24HourFormat(context))
        timePickerDialog.show()
    }
    override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
        myHour = hourOfDay
        myMinute = minute
        textView.text =formatDate(myYear,myMonth,myDay,myHour,myMinute)
        date=calendar.time
        today=formatDate(myYear,myMonth,myDay)!!
        clock=formatDate(myHour,myMinute)!!

        // "Year: " + myYear + "\n" + "Month: " + myMonth + "\n" + "Day: " + myDay + "\n" + "Hour: " + myHour + "\n" + "Minute: " + myMinute
    }
    private fun formatDate(year: Int, month: Int, day: Int,hour:Int,minute: Int): String? {
//        val cal = Calendar.getInstance()
//        calendar.timeInMillis = 0
        calendar[year, month,day,hour,minute] =day
        val dates = calendar.time
        val sdf = SimpleDateFormat("dd/MM/yyyy hh:mm aa")
        return sdf.format(dates)
    }
    private fun formatDate(year: Int, month: Int, day: Int): String? {
//        val cal = Calendar.getInstance()
//        calendar.timeInMillis = 0
        calendar[year, month,day,hour,minute] =day
        val dates = calendar.time
        val sdf = SimpleDateFormat("dd/MM/yyyy")
        return sdf.format(dates)
    }
    private fun formatDate(hour:Int,minute: Int): String? {
//        val cal = Calendar.getInstance()
//        calendar.timeInMillis = 0
        calendar[year, month,day,hour,minute] =day
        val dates = calendar.time
        val sdf = SimpleDateFormat("hh:mm aa")
        return sdf.format(dates)
    }
}
