package com.example.android.mytodoapp.tasks.taskadapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.android.mytodoapp.R
import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.databinding.TaskItemBinding
import com.example.android.mytodoapp.tasks.TaskItemListener
import com.example.android.mytodoapp.tasks.TasksFragment

//import com.example.android.mytodoapp.databinding

class SleepNightAdapter(val clickListener: TaskItemListener) :
    ListAdapter<Task, SleepNightAdapter.ViewHolder>(SleepNightDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        return ViewHolder.from(parent)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(clickListener, getItem(position)!!)
//        val item =getItem(position)
//        holder.bind(item)

    }


    class ViewHolder private constructor(val binding: TaskItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(clickListener: TaskItemListener, item: Task) {

//            val res = itemView.context.resources


//            if (item.isCompleted)binding.textWeights.text


            binding.run {
                sleep = item
                binding.clickListener = clickListener

                buttonDelete.visibility = if (item.isRemoved) View.VISIBLE else View.GONE

                with(complete) {
                    // Active/completed task UI
                    isChecked = item.isCompleted

                    if (item.isCompleted) {
                        textWeights.text = "COMPLETED"
                        textWeights.setTextColor(Color.DKGRAY)
                    } else {
                        textWeights.text = "ACTIVE"
                        textWeights.setTextColor(Color.GREEN)
                    }

                    setOnClickListener {
                        if (!item.isCompleted) {
                            clickListener.onCompleteTaskClick(item)
                        } else {
                            clickListener.onActivateTaskClick(item)

                        }
                    }
                }

//
//                if (item.isCompleted) {
//                    textWeights.text = "COMPLETED"
//                    textWeights.setTextColor(Color.DKGRAY)
//                } else {
//                    textWeights.text = "ACTIVE"
//                    textWeights.setTextColor(Color.GREEN)
//                }
                layoutLeft.run {
                    when {
                        com.example.android.mytodoapp.util.compareDate(item.time!!) == 0 -> {
                            setBackgroundColor(Color.RED)
                        }
                        com.example.android.mytodoapp.util.compareDate(item.time!!) == 3 -> {
                            setBackgroundColor(Color.YELLOW)
                        }
                        com.example.android.mytodoapp.util.compareDate(item.time!!) == 1 -> {
                            setBackgroundColor(Color.BLACK)
                            clickListener.onOldTask(item)
                        }
                        com.example.android.mytodoapp.util.compareDate(item.time!!) == -1 -> {
                            setBackgroundColor(Color.GREEN)
                        }
                    }
                }


                title.text = item.title
                textTo.text = item.description
                textDate.text = item.day
                texTime.text = item.clock
                textAmount.text = item.hashTag
                executePendingBindings()
            }


        }

        companion object {
            fun from(parent: ViewGroup): ViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = TaskItemBinding.inflate(layoutInflater, parent, false)
//                val view = LayoutInflater.from(parent.context).inflate(R.layout.task_item, parent, false)

                return ViewHolder(binding)
            }
        }
    }
}

class SleepNightDiffCallback : DiffUtil.ItemCallback<Task>() {
    override fun areItemsTheSame(oldItem: Task, newItem: Task): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Task, newItem: Task): Boolean {
        return oldItem == newItem && oldItem.isCompleted==newItem.isCompleted
    }

}

//class SleepNightListener(val clickListener: (sleepId: Task) -> Unit) {
//    fun onClick(night: Task) = clickListener(night)
//    fun onTaskClick(clickedTask: Task) {}
//    fun onEditTaskClick(clickedTask: Task) {}
//    fun onOldTask(oldTask: Task) {}
//    fun onCompleteTaskClick(completedTask: Task) {}
//    fun onCanceledTaskClcik(canceledTask: Task) {}
//    fun onRemoveTaskClick(completedTask: Task) {}
//    fun onDeleteTaskClcik(deletedTask: Task) {}
//    fun onActivateTaskClick(activatedTask: Task) {}
//}



//class TextItemViewHolder(val textView: TextView): RecyclerView.ViewHolder(textView)/**/


//import android.annotation.SuppressLint
//import android.graphics.Color
//import android.view.View
//import android.view.ViewGroup
//import androidx.recyclerview.widget.RecyclerView
//import com.example.android.mytodoapp.R
//import kotlinx.android.synthetic.main.task_item.view.*
//import com.example.android.mytodoapp.data.Task
//import com.example.android.mytodoapp.tasks.TasksFragment
//import com.example.android.mytodoapp.util.compareDate
//import com.example.android.mytodoapp.util.inflate
//
////import com.example.android.ussdpractise.R
////import kotlinx.android.synthetic.main.list_item.view.*
////import com.example.android.ussdpractise.data.source.models.TariffData
////import com.example.android.mytodoapp.util.inflate
//
//class TaskRecyclerViewAdapter(private val itemListener: TasksFragment.TaskItemListener) : RecyclerView.Adapter<TaskRecyclerViewAdapter.ViewHolder>() {
//    private val data = ArrayList<Task>()
//    private var listener: ItemClick<Task>? = null
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
//        ViewHolder(parent.inflate(R.layout.task_item))
//
//    override fun getItemCount(): Int = data.size
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind()
//
//    fun addItems(items: List<Task>) {
//        data.clear()
//        data.addAll(items)
//        notifyDataSetChanged()
//    }
//
//    fun setOnItemClickListener(f: ItemClick<Task>) {
//        listener = f
//    }
//
//    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//        init {
//            itemView.apply {
//                card_item.setOnClickListener { listener?.invoke(data[adapterPosition]) }
//            }
//        }
//
//        @SuppressLint("SetTextI18n")
//        fun bind() {
//            val d = data[adapterPosition]
//            itemView.apply {
//                title.text = d.title
//                layoutLeft.let {
//                    when {
//                        compareDate(d.time!!) == 0 -> {
//
//                            setBackgroundColor(Color.RED)
//                        }
//                        compareDate(d.time!!) == 3 -> {
//                            setBackgroundColor(Color.YELLOW)
//                        }
//                        compareDate(d.time!!) == 1 -> {
//                            setBackgroundColor(Color.BLACK)
////                     itemListener.onOldTask(d)
//                        }
//                        compareDate(d.time!!) == -1 -> {
//                            setBackgroundColor(Color.GREEN)
//                        }
//                    }
//                }
//                textTo.text = d.description
//                textDate.text = d.day
//                texTime.text = d.clock
//                textAmount.text = d.hashTag
//                textRequests.setOnClickListener { itemListener.onEditTaskClick(d) }
//                buttonDelete.setOnClickListener { itemListener.onDeleteTaskClcik(d) }
//                textPledges.let {
//                    if (d.isRemoved) {
//                        setBackgroundResource(R.drawable.ic_baseline_restore_from_trash)
//                     buttonDelete.visibility = android.view.View.VISIBLE
//
//                    } else {
//                        setBackgroundResource(R.drawable.ic_baseline_delete)
//                   buttonDelete.visibility = android.view.View.GONE
//
//                    }
//
//                    setOnClickListener {
////                    if (!task.isRemoved) {
//                        itemListener.onRemoveTaskClick(d)
////                    } else {
//////                    itemListener.onActivateTaskClick(task)
////                    }
//                    }
//                }
//                buttonCancel.setOnClickListener { itemListener.onCanceledTaskClcik(d) }
//                complete.let {
//                    // Active/completed task UI
//                    it.isChecked = d.isCompleted
//
//                    if (d.isCompleted) {
//                        textWeights.text = "COMPLETED"
//                     textWeights.setTextColor(Color.DKGRAY)
//                    } else {
//                        textWeights.text = "ACTIVE"
//         textWeights.setTextColor(Color.GREEN)
//                    }
//
//                    setOnClickListener {
//                        if (!d.isCompleted) {
//                            itemListener.onCompleteTaskClick(d)
//                        } else {
//                            itemListener.onActivateTaskClick(d)
//                        }
//                    }
//                }
////              itemListener.onTaskClick(d)
//
//            }
//        }
//    }
//}
//
//typealias ItemClick<T> = (T) -> Unit



