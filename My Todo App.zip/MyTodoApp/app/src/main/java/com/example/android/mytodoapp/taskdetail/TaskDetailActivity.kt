package com.example.android.mytodoapp.taskdetail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.android.mytodoapp.mock.Injection
import com.example.android.mytodoapp.R
import com.example.android.mytodoapp.util.replaceFragmentInActivity
import com.example.android.mytodoapp.util.setupActionBar

class TaskDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.taskdetail_act)

        // Set up the toolbar.
        setupActionBar(R.id.toolbar) {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
        }

        // Get the requested task id
        val taskId = intent.getStringExtra(EXTRA_TASK_ID)
    /*    val edit = intent.getStringExtra("edit")
        if (edit=="edit"){
            val intent = Intent(this, AddEditTaskActivity::class.java)
            intent.putExtra(AddEditTaskFragment.ARGUMENT_EDIT_TASK_ID, taskId)
            startActivityForResult(intent, TaskDetailFragment.REQUEST_EDIT_TASK)
            finish()
        }*/

        val taskDetailFragment = supportFragmentManager
            .findFragmentById(R.id.contentFrame) as TaskDetailFragment? ?:
        TaskDetailFragment.newInstance(taskId).also {
            replaceFragmentInActivity(it, R.id.contentFrame)
        }
        // Create the presenter
        TaskDetailPresenter(taskId, Injection.provideTasksRepository(applicationContext),
            taskDetailFragment)
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    companion object {
        const val EXTRA_TASK_ID = "TASK_ID"
    }
}
