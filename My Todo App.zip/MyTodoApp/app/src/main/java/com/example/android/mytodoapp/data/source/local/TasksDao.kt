package com.example.android.mytodoapp.data.source.local

import androidx.room.*
import com.example.android.mytodoapp.data.Task

@Dao
interface TasksDao {
    @Query("select * from tasks order by time  ")
    fun getTasks(): List<Task>

    @Query("Select * from tasks where entryid=:taskId")
    fun getTaskById(taskId: String): Task?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTask(task: Task)

    @Update
    fun updateTask(task: Task): Int

    @Query("Update tasks set completed=:completed where entryid=:taskId")
    fun updateCompleted(taskId: String, completed: Boolean)
    @Query("Update tasks set old=:old where entryid=:taskId")
    fun upDateOld(taskId: String, old: Boolean)
    @Query("Update tasks set canceled=:canceled where entryid=:taskId")
    fun upDateCanceled(taskId: String, canceled: Boolean)

    @Query("Update tasks set removed=:removed where entryid=:taskId")
    fun updateRemoved(taskId: String, removed: Boolean)

    @Query("Delete from tasks where entryid=:taskId")
    fun deleteTaskById(taskId: String): Int

    @Query("delete from tasks")
    fun deleteTasks()

    @Query("delete from tasks where completed = 1")
    fun deleteCompletedTasks(): Int
}