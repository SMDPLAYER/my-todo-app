package com.example.android.mytodoapp

interface BasePresenter {
    fun start()
}