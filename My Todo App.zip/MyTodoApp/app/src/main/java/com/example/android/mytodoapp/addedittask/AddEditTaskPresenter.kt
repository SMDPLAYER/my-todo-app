package com.example.android.mytodoapp.addedittask

import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.data.source.TasksDataSource
import java.util.*

class AddEditTaskPresenter(
    private val taskId: String?,
    val tasksRepository: TasksDataSource,
    val addTaskView: AddEditTaskContract.View,
    override var isDataMissing: Boolean
) : AddEditTaskContract.Presenter, TasksDataSource.GetTaskCallback {
    init {
        addTaskView.presenter = this
    }

    override fun start() {
        if (taskId != null && isDataMissing) {
            populateTask()
        }
    }

    override fun saveTask(title: String, description: String,time:Date,day: String, clock: String,hashTag: String) {
        if (taskId == null) {
            createTask(title, description,time,day,clock ,hashTag)
        } else {
            updateTask(title, description,time,day,clock ,hashTag)
        }
    }

    override fun populateTask() {
        if (taskId == null) {
            throw RuntimeException("populateTask() was called but task is new.")
        }
        tasksRepository.getTask(taskId, this)
    }

    override fun onTaskLoaded(task: Task) {
        if (addTaskView.isActive) {
            addTaskView.setTitle(task.title)
            addTaskView.setDescription(task.description)
            addTaskView.setTime(task.time,task.day,task.clock)
            addTaskView.setHashTag(task.hashTag)
        }
    }

    override fun onDataNotAvailable() {
        if (addTaskView.isActive) {
            addTaskView.showEmptyTaskError()
        }
    }

    private fun createTask(
        title: String,
        description: String,
        time: Date,
        day: String,
        clock: String,
        hashTag: String

    ) {
        val newTask = Task(title, description,time,day,clock,hashTag)
        if (newTask.isEmpty) {
            addTaskView.showEmptyTaskError()
        } else {
            tasksRepository.saveTask(newTask)
            addTaskView.showTasksList()
        }
    }

    private fun updateTask(
        title: String,
        description: String,
        time: Date,
        day: String,
        clock: String,
        hashTag: String
    ) {
        if (taskId == null) {
            throw RuntimeException("updateTask() was called but task is new.")
        }
        tasksRepository.saveTask(Task(title, description,time,day,clock,hashTag,taskId))
        addTaskView.showTasksList()
    }
}