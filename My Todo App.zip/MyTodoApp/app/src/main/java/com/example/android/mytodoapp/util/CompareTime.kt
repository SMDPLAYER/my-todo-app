package com.example.android.mytodoapp.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.*

fun compareDate(valid_until: Date): Int {
//    val sdf = SimpleDateFormat("dd/MM/yyyy")
//    val strDate = sdf.parse(valid_until)

    return when {
        printDifference(System.currentTimeMillis(), valid_until.time) < 0 -> {
            1
        }
        printDifference(valid_until.time, System.currentTimeMillis()) == 0-> {
            0
        }
        printDifference(System.currentTimeMillis(), valid_until.time) < 3 && valid_until.time > System.currentTimeMillis() -> {
            3
        }
//        printDifference(valid_until.time, System.currentTimeMillis()) > 0 -> {
//
//            -1
//        }

        else -> {
            -1
        }

    }
}

fun formatDates(year: Int, month: Int, day: Int, hour: Int, minute: Int): String? {
    val cal = Calendar.getInstance()
    cal.timeInMillis = 0
    cal[year, month, day, hour, minute] = day
    val dates = cal.time
    val sdf = SimpleDateFormat("dd/MM/yyyy")
    return sdf.format(dates)
}

fun printDifference(startDate: Long, endDate: Long): Int {
    //milliseconds
    var different = endDate - startDate
//    println("startDate : $startDate")
//    println("endDate : $endDate")
//    println("different : $different")
    val secondsInMilli: Long = 1000
    val minutesInMilli = secondsInMilli * 60
    val hoursInMilli = minutesInMilli * 60
    val daysInMilli = hoursInMilli * 24

    val elapsedDays = (endDate/daysInMilli).toInt()-(startDate/daysInMilli).toInt()//different / daysInMilli
//    different = different % daysInMilli
//    val elapsedHours = different / hoursInMilli
//    different = different % hoursInMilli
//    val elapsedMinutes = different / minutesInMilli
//    different = different % minutesInMilli
//    val elapsedSeconds = different / secondsInMilli
//    Log.v(
//        "TTTT",
//        "$elapsedDays, $elapsedHours, $elapsedMinutes, $elapsedSeconds"
//    )
    return elapsedDays
}