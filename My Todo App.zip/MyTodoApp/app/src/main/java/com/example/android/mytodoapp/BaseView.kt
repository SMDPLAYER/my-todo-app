package com.example.android.mytodoapp

interface BaseView<T> {
    var presenter: T
}