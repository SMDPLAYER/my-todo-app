package com.example.android.mytodoapp.tasks

import com.example.android.mytodoapp.BasePresenter
import com.example.android.mytodoapp.BaseView
import com.example.android.mytodoapp.data.Task

/**
 * This specifies the contract between the view and the presenter.
 */
interface TasksContract {

    interface View : BaseView<Presenter> {

        var isActive: Boolean

        fun setLoadingIndicator(active: Boolean)

        fun showTasks(tasks: List<Task>)

        fun showAddTask()

        fun showTaskDetailsUi(taskId: String)
        fun showEditTask(taskId: String)

        fun showTaskMarkedComplete()
fun showTaskCanceled()
        fun showTaskMarkedActive()

        fun showCompletedTasksCleared()

        fun showLoadingTasksError()

        fun showNoTasks()

        fun showActiveFilterLabel()

        fun showCompletedFilterLabel()
        fun showDeletedFilterLabel()
        fun showHistoryFilterLabel()


        fun showAllFilterLabel()

        fun showNoActiveTasks()

        fun showNoCompletedTasks()

        fun showSuccessfullySavedMessage()
        fun showTaskDeleted()
        fun showFilteringPopUpMenu()
    }

    interface Presenter : BasePresenter {

        var currentFiltering: TasksFilterType

        fun result(requestCode: Int, resultCode: Int)

        fun loadTasks(forceUpdate: Boolean)

        fun addNewTask()

        //        fun deleteTask(trequestedTask: Task)
        fun openTaskDetails(requestedTask: Task)

        fun openEditTask(requestedTask: Task)
        fun completeTask(completedTask: Task)
        fun cancelTask(completedTask: Task)
        fun oldTask(completedTask: Task)
        fun removeTask(removedTask: Task)
fun deleteTask(deletedTask: Task)
        fun activateTask(activeTask: Task)

        fun clearCompletedTasks()
    }
}
