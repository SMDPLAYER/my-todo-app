package com.example.android.mytodoapp.data

import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.example.android.mytodoapp.util.TimestampConverter
import java.io.Serializable
import java.util.*

@Entity(tableName = "tasks")
data class Task @JvmOverloads constructor(
    @ColumnInfo(name = "title")
    var title: String = "",
    @ColumnInfo(name = "description")
    var description: String = "",
    @NonNull
    @ColumnInfo(name = "time")
    @TypeConverters(TimestampConverter::class)
    var time: Date? = null,
    @ColumnInfo(name = "day")
    var day: String = "",
    @ColumnInfo(name = "clock")
    var clock: String = "",
    @ColumnInfo(name = "hashTag")
    var hashTag: String = "",
    @PrimaryKey @ColumnInfo(name = "entryid")
    var id: String = UUID.randomUUID().toString()
) : Serializable {
    @ColumnInfo(name = "completed")
    var isCompleted = false

    @ColumnInfo(name = "canceled")
    var isCanceled = false

    @ColumnInfo(name = "old")
    var isOld = false

    @ColumnInfo(name = "removed")
    var isRemoved = false

    val titleForList: String
        get() = if (title.isNotEmpty()) title else description

    val isActive
        get() = !isCompleted
    val isAlive
        get() = !isRemoved
    val isAnew
        get() = !isOld


    val isEmpty
        get() = title.isEmpty() && description.isEmpty()

}