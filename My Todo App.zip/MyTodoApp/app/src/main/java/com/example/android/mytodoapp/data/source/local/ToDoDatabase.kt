package com.example.android.mytodoapp.data.source.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.util.Converters

@Database(entities = [Task::class], version = 1)
@TypeConverters(Converters::class)
abstract class ToDoDatabase : RoomDatabase() {
    abstract fun taskDao(): TasksDao

    companion object {
        @Volatile
        private var INSTANCE: ToDoDatabase? = null
        private val lock = Any()
        fun getInstance(context: Context): ToDoDatabase {
            synchronized(this) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                        context.applicationContext,
                        ToDoDatabase::class.java, "MyTasks.db"
                    ).allowMainThreadQueries()
                        .build()
                }
                return INSTANCE!!
            }

        }
    }


}