package com.example.android.mytodoapp.util

import com.google.android.material.snackbar.Snackbar
import android.view.View

fun View.showSnackBar(message: String, duration: Int) {
    Snackbar.make(this, message, duration).show()
}

