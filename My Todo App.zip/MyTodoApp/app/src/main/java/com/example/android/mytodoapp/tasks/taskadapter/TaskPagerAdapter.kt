package com.example.android.mytodoapp.tasks.taskadapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.android.mytodoapp.app.App
import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.data.source.local.ToDoDatabase
import com.example.android.mytodoapp.tasks.TasksFragment
import com.example.android.mytodoapp.util.putArguments

//import androidx.fragment.app.Fragment
//import androidx.fragment.app.FragmentActivity
//import androidx.viewpager2.adapter.FragmentStateAdapter
//import com.example.android.mytodoapp.data.Task
//import com.example.android.mytodoapp.tasks.TasksFilterType
//
////import com.example.android.ussdpractise.data.source.models.TariffData
////import com.example.android.ussdpractise.data.source.models.TariffType
////import com.example.android.ussdpractise.ui.fragments.TariffFragment
////import com.example.android.mytodoapp.util.putArguments
//
class TaskPagerAdapter(allData: List<Task>, activity: FragmentActivity) :
    FragmentStateAdapter(activity) {
//    private var listener: ItemClick<Task>? = null
    private val data: ArrayList<List<Task>> = ArrayList()
    val database = ToDoDatabase.getInstance(App.instance)
    val dataTask= database.taskDao().getTasks()


    init {
        data.add(dataTask.filter { it.isActive})
        data.add(dataTask.filter { it.isCompleted})
        data.add(dataTask.filter { it.isOld })
        data.add(dataTask.filter { it.isCanceled})
    }

    override fun getItemCount(): Int = data.size
    override fun createFragment(position: Int): Fragment = TasksFragment()

        .putArguments {
            val filtered = FilteredSerializableList(data[position])
            putSerializable("DATA", filtered)
        }

//    fun setButtonClickListener(f: ItemClick<TariffData>) {
//        listener = f
//    }
}