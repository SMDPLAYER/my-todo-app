package com.example.android.mytodoapp.addedittask

import com.example.android.mytodoapp.BasePresenter
import com.example.android.mytodoapp.BaseView
import java.util.*

interface AddEditTaskContract {

    interface View : BaseView<Presenter> {
        var isActive: Boolean


        fun showEmptyTaskError()
        fun showTasksList()
        fun setTitle(title: String)
        fun setHashTag(hashTag:String)

        fun setDescription(description: String)
        fun setTime(time: Date?,today:String,clock: String)
//        fun setDate(day:String,clock:String)
    }

    interface Presenter : BasePresenter {
        var isDataMissing: Boolean

        fun saveTask(title: String, description: String,time: Date,day: String, clock: String,hashTag: String)
        fun populateTask()
    }
}