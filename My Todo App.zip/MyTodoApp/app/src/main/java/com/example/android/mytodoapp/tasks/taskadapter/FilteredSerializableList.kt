package com.example.android.mytodoapp.tasks.taskadapter

import com.example.android.mytodoapp.data.Task
import java.io.Serializable

data class FilteredSerializableList(
    var list: List<Task>
) : Serializable