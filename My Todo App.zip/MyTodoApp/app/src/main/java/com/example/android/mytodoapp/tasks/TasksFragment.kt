package com.example.android.mytodoapp.tasks

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.android.mytodoapp.R
import com.example.android.mytodoapp.addedittask.AddEditTaskActivity
import com.example.android.mytodoapp.addedittask.AddEditTaskFragment
import com.example.android.mytodoapp.app.App
import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.mock.Injection
import com.example.android.mytodoapp.taskdetail.TaskDetailActivity
import com.example.android.mytodoapp.taskdetail.TaskDetailFragment
import com.example.android.mytodoapp.tasks.taskadapter.FilteredSerializableList
import com.example.android.mytodoapp.tasks.taskadapter.SleepNightAdapter
//import com.example.android.mytodoapp.tasks.taskadapter.SleepNightListener
import com.example.android.mytodoapp.util.compareDate
import com.example.android.mytodoapp.util.showSnackBar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import java.util.*

class TasksFragment : Fragment(), TasksContract.View {
/*//RECYCLERVIEW
private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    ///REcyclerView*/
    override lateinit var presenter: TasksContract.Presenter

    override var isActive: Boolean = false
        get() = isAdded

    private lateinit var noTasksView: View
    private lateinit var noTaskIcon: ImageView
    private lateinit var noTaskMainView: TextView
    private lateinit var noTaskAddView: TextView
    private lateinit var tasksView: LinearLayout
    private lateinit var filteringLabelView: TextView

    /**
     * Listener for clicks on tasks in the ListView.
     */
    internal var itemListener: TaskItemListener = object : TaskItemListener {
        override fun onTaskClick(clickedTask: Task) {
            presenter.openTaskDetails(clickedTask)
        }

        override fun onEditTaskClick(clickedTask: Task) {
            presenter.openEditTask(clickedTask)
        }

        override fun onCompleteTaskClick(completedTask: Task) {
            if (completedTask.isCompleted)
                presenter.activateTask(completedTask)
            else
            presenter.completeTask(completedTask)
        }
        override fun onOldTask(oldTask: Task) {
            presenter.oldTask(oldTask)
        }

        override fun onCanceledTaskClcik(canceledTask: Task) {
            presenter.cancelTask(canceledTask)
        }

        override fun onRemoveTaskClick(removedTask: Task) {
            presenter.removeTask(removedTask)
        }

        override fun onDeleteTaskClcik(deletedTask: Task) {
            presenter.deleteTask(deletedTask)
        }

        override fun onActivateTaskClick(activatedTask: Task) {
            presenter.activateTask(activatedTask)
        }
    }

//    private val listAdapter = TasksAdapter(ArrayList(0), itemListener)
    private val listAdapter = SleepNightAdapter(itemListener)

//    private val listAdapter = TaskRecyclerViewAdapter(itemListener)


    override fun onResume() {
        super.onResume()
        presenter.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        presenter.result(requestCode, resultCode)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        val root = inflater.inflate(R.layout.tasks_frag, container, false)
        presenter = TasksPresenter(
            Injection.provideTasksRepository(App.instance),
            this).apply {
            // Load previously saved state, if available.
            if (savedInstanceState != null) {
                currentFiltering = savedInstanceState.getSerializable("CURRENT_FILTERING_KEY")
                        as TasksFilterType
            }
        }
        // Set up tasks view
        with(root) {
            val listView = findViewById<RecyclerView>(R.id.tasks_list).apply { adapter = listAdapter }
//            listView.layoutManager =
//                LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)

            // Set up progress indicator
            findViewById<ScrollChildSwipeRefreshLayout>(R.id.refresh_layout).apply {
                setColorSchemeColors(
                    ContextCompat.getColor(requireContext(), R.color.colorPrimary),
                    ContextCompat.getColor(requireContext(), R.color.colorAccent),
                    ContextCompat.getColor(requireContext(), R.color.colorPrimaryDark)
                )
                // Set the scrolling view in the custom SwipeRefreshLayout.
                scrollUpChild = listView
                setOnRefreshListener { presenter.loadTasks(false) }
            }

            filteringLabelView = findViewById(R.id.filteringLabel)
            tasksView = findViewById(R.id.tasksLL)

            // Set up  no tasks view
            noTasksView = findViewById(R.id.noTasks)
            noTaskIcon = findViewById(R.id.noTasksIcon)
            noTaskMainView = findViewById(R.id.noTasksMain)
            noTaskAddView = (findViewById<TextView>(R.id.noTasksAdd)).also {
                it.setOnClickListener { showAddTask() }
            }

/*            ///REcyclerView
            viewManager = LinearLayoutManager(context)
            viewAdapter = MyAdapter(myDataset)

            recyclerView = findViewById<RecyclerView>(R.id.my_recycler_view).apply {
                // use this setting to improve performance if you know that changes
                // in content do not change the layout size of the RecyclerView
                setHasFixedSize(true)

                // use a linear layout manager
                layoutManager = viewManager

                // specify an viewAdapter (see also next example)
                adapter = viewAdapter

            }*/



        }

        // Set up floating action button
        requireActivity().findViewById<FloatingActionButton>(R.id.fab_add_task).apply {
            setImageResource(R.drawable.ic_add)
            setOnClickListener { presenter.addNewTask() }
        }
        setHasOptionsMenu(true)





        return root
    }

//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//
//
//    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_clear -> presenter.clearCompletedTasks()
            R.id.menu_filter -> showFilteringPopUpMenu()
            R.id.menu_refresh -> presenter.loadTasks(true)
        }
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.tasks_fragment_menu, menu)
    }


    override fun showFilteringPopUpMenu() {
        val activity = activity ?: return
        val context = context ?: return
        PopupMenu(context, activity.findViewById(R.id.menu_filter)).apply {
            menuInflater.inflate(R.menu.filter_tasks, menu)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.active -> presenter.currentFiltering = TasksFilterType.ACTIVE_TASKS
                    R.id.completed -> presenter.currentFiltering = TasksFilterType.COMPLETED_TASKS
                    R.id.deleted -> { presenter.currentFiltering = TasksFilterType.DELETED_TASKS }
                    R.id.history -> { presenter.currentFiltering = TasksFilterType.HISTORY }
                    R.id.canceled->{ presenter.currentFiltering = TasksFilterType.CANCELED}
                    else -> presenter.currentFiltering = TasksFilterType.ALL_TASKS
                }
                presenter.loadTasks(false)
                true
            }
            show()
        }
    }

    override fun setLoadingIndicator(active: Boolean) {
        val root = view ?: return
        with(root.findViewById<SwipeRefreshLayout>(R.id.refresh_layout)) {
            // Make sure setRefreshing() is called after the layout is done with everything else.
            post { isRefreshing = active }
        }
    }

    override fun showTasks(tasks: List<Task>) {
//        listAdapter.submitList(tasks)


        val bundle = requireArguments()
        val filteredSerializableList = bundle.getSerializable("DATA") as FilteredSerializableList
        val data = filteredSerializableList.list

        val dat=tasks
        listAdapter.submitList(tasks)
        listAdapter.submitList(data)

//listAdapter.submitList(tasks)

//        listAdapter.addItems(tasks)
        tasksView.visibility = View.VISIBLE
        noTasksView.visibility = View.GONE
    }

    override fun showNoActiveTasks() {
        showNoTasksViews(
            resources.getString(R.string.no_tasks_active),
            R.drawable.ic_check_circle_24dp,
            false
        )
    }

    override fun showNoTasks() {
        showNoTasksViews(
            resources.getString(R.string.no_tasks_all),
            R.drawable.ic_assignment_turned_in_24dp,
            false
        )
    }

    override fun showNoCompletedTasks() {
        showNoTasksViews(
            resources.getString(R.string.no_tasks_completed),
            R.drawable.ic_verified_user_24dp,
            false
        )
    }

    override fun showSuccessfullySavedMessage() {
        showMessage(getString(R.string.successfully_saved_task_message))
    }

    override fun showTaskDeleted() {
        showMessage(getString(R.string.task_deleted))

//      listAdapter.notifyDataSetChanged()
    }

    private fun showNoTasksViews(mainText: String, iconRes: Int, showAddView: Boolean) {
        tasksView.visibility = View.GONE
        noTasksView.visibility = View.VISIBLE

        noTaskMainView.text = mainText
        noTaskIcon.setImageResource(iconRes)
        noTaskAddView.visibility = if (showAddView) View.VISIBLE else View.GONE
    }

    override fun showActiveFilterLabel() {
        filteringLabelView.text = resources.getString(R.string.label_active)
    }

    override fun showCompletedFilterLabel() {
        filteringLabelView.text = resources.getString(R.string.label_completed)
    }

    override fun showDeletedFilterLabel() {
        filteringLabelView.text = resources.getString(R.string.label_deleted)
    }

    override fun showHistoryFilterLabel() {
        filteringLabelView.text = resources.getString(R.string.label_history)
    }


    override fun showAllFilterLabel() {
        filteringLabelView.text = resources.getString(R.string.label_all)
    }

    override fun showAddTask() {
        val intent = Intent(context, AddEditTaskActivity::class.java)
        startActivityForResult(intent, AddEditTaskActivity.REQUEST_ADD_TASK)
    }

    override fun showTaskDetailsUi(taskId: String) {
        // in it's own Activity, since it makes more sense that way and it gives us the flexibility
        // to show some Intent stubbing.
        val intent = Intent(context, TaskDetailActivity::class.java).apply {
            putExtra(TaskDetailActivity.EXTRA_TASK_ID, taskId)
            putExtra("edit", "")
        }
        startActivity(intent)
    }

    override fun showEditTask(taskId: String) {
        // in it's own Activity, since it makes more sense that way and it gives us the flexibility
        // to show some Intent stubbing.
        /*   val intent = Intent(context, AddEditTaskActivity::class.java).apply {
               putExtra(TaskDetailActivity.EXTRA_TASK_ID, taskId)
               putExtra("edit", "edit")
           }
           startActivity(intent)*/


        val intent = Intent(context, AddEditTaskActivity::class.java)
        intent.putExtra(AddEditTaskFragment.ARGUMENT_EDIT_TASK_ID, taskId)
        startActivityForResult(intent, TaskDetailFragment.REQUEST_EDIT_TASK)
    }

    override fun showTaskMarkedComplete() {
        showMessage(getString(R.string.task_marked_complete))
    }

    override fun showTaskCanceled() {
        showMessage(getString(R.string.task_canceled))
    }

    override fun showTaskMarkedActive() {
        showMessage(getString(R.string.task_marked_active))
    }

    override fun showCompletedTasksCleared() {
        showMessage(getString(R.string.completed_tasks_cleared))
    }

    override fun showLoadingTasksError() {
        showMessage(getString(R.string.loading_tasks_error))
    }

    private fun showMessage(message: String) {
        view?.showSnackBar(message, Snackbar.LENGTH_LONG)
    }

    private class TasksAdapter(tasks: List<Task>, private val itemListener: TaskItemListener) :
        BaseAdapter() {

        var tasks: List<Task> = tasks
            set(tasks) {
                field = tasks
                notifyDataSetChanged()
            }

        override fun getCount() = tasks.size

        override fun getItem(i: Int) = tasks[i]

        override fun getItemId(i: Int) = i.toLong()

        override fun getView(i: Int, view: View?, viewGroup: ViewGroup): View {

            val task = getItem(i)
            val rowView = view ?: LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.task_item, viewGroup, false)

            with(rowView.findViewById<TextView>(R.id.title)) {
                text = task.titleForList

            }
            with(rowView.findViewById<View>(R.id.layoutLeft)) {
                when {
                    compareDate(task.time!!) == 0 -> {

                        setBackgroundColor(Color.RED)
                    }
                    compareDate(task.time!!) == 3 -> {
                        setBackgroundColor(Color.YELLOW)
                    }
                    compareDate(task.time!!) == 1 -> {
                        setBackgroundColor(Color.BLACK)
                        itemListener.onOldTask(task)
                    }
                    compareDate(task.time!!) == -1 -> {
                        setBackgroundColor(Color.GREEN)
                    }
                }

            }
            with(rowView.findViewById<TextView>(R.id.textTo)) {
                text = task.description

            }
            with(rowView.findViewById<TextView>(R.id.textDate)) {
//                if(compareDate(task.time!!)==0)text="Today"
//                else
                text = task.day

            }
            with(rowView.findViewById<TextView>(R.id.texTime)) {
                text = task.clock

            }
            with(rowView.findViewById<TextView>(R.id.textAmount)) {
                text = task.hashTag

            }
            with(rowView.findViewById<ImageButton>(R.id.textRequests)) {
                setOnClickListener { itemListener.onEditTaskClick(task) }
            }
            with(rowView.findViewById<ImageButton>(R.id.buttonDelete)) {
                setOnClickListener { itemListener.onDeleteTaskClcik(task) }
            }
            with(rowView.findViewById<ImageButton>(R.id.textPledges)) {
                if (task.isRemoved) {
                    setBackgroundResource(R.drawable.ic_baseline_restore_from_trash)
                    with(rowView.findViewById<ImageButton>(R.id.buttonDelete)) {
                        visibility = View.VISIBLE
                    }
                } else {
                    setBackgroundResource(R.drawable.ic_baseline_delete)
                    with(rowView.findViewById<ImageButton>(R.id.buttonDelete)) {
                        visibility = View.GONE
                    }
                }

                setOnClickListener {
//                    if (!task.isRemoved) {
                    itemListener.onRemoveTaskClick(task)
//                    } else {
////                    itemListener.onActivateTaskClick(task)
//                    }
                }

            }
            with(rowView.findViewById<ImageButton>(R.id.buttonCancel)) {
                setOnClickListener { itemListener.onCanceledTaskClcik(task) }
            }
            with(rowView.findViewById<CheckBox>(R.id.complete)) {
                // Active/completed task UI
                isChecked = task.isCompleted

                if (task.isCompleted) {
                    rowView.findViewById<TextView>(R.id.textWeights).setText("COMPLETED")
                    rowView.findViewById<TextView>(R.id.textWeights).setTextColor(Color.DKGRAY)
                } else {
                    rowView.findViewById<TextView>(R.id.textWeights).setText("ACTIVE")
                    rowView.findViewById<TextView>(R.id.textWeights).setTextColor(Color.GREEN)
                }

                setOnClickListener {
                    if (!task.isCompleted) {
                        itemListener.onCompleteTaskClick(task)
                    } else {
                        itemListener.onActivateTaskClick(task)
                    }
                }
            }
            rowView.setOnClickListener { itemListener.onTaskClick(task) }
            return rowView
        }
    }

//    class CustomComparator : Comparator<Task> {
//        // may be it would be Model
//        override fun compare(obj1: Task, obj2: Task): Int {
//            return obj1.time.compareTo(obj2.time) // compare two objects
//        }
//    }

    companion object {
        private val REQUEST_EDIT_TASK = 1
        fun newInstance() = TasksFragment()
//       lateinit var  dataTask:List<Task>
    }

}

interface TaskItemListener {

    fun onTaskClick(clickedTask: Task)
    fun onEditTaskClick(clickedTask: Task)
    fun onOldTask(oldTask:Task)
    fun onCompleteTaskClick(completedTask: Task)
    fun onCanceledTaskClcik(canceledTask: Task)
    fun onRemoveTaskClick(removedTask: Task)
    fun onDeleteTaskClcik(deletedTask: Task)
    fun onActivateTaskClick(activatedTask: Task)
}