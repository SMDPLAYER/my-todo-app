package com.example.android.mytodoapp.tasks

import android.app.Activity
import com.example.android.mytodoapp.addedittask.AddEditTaskActivity
import com.example.android.mytodoapp.data.Task
import com.example.android.mytodoapp.data.source.TasksDataSource
import com.example.android.mytodoapp.data.source.TasksRepository
import com.example.android.mytodoapp.taskdetail.TaskDetailFragment
import com.example.android.mytodoapp.util.EspressoIdlingResource
import java.util.ArrayList

/**
 * Listens to user actions from the UI ([TasksFragment]), retrieves the data and updates the
 * UI as required.
 */
class TasksPresenter(
    private val tasksRepository: TasksRepository,
    val tasksView: TasksContract.View
) : TasksContract.Presenter {

    override var currentFiltering = TasksFilterType.ALL_TASKS

    private var firstLoad = true

    init {
        tasksView.presenter = this
    }

    override fun start() {
        loadTasks(false)
    }

    override fun result(requestCode: Int, resultCode: Int) {
        // If a task was successfully added, show snackBar
        if (AddEditTaskActivity.REQUEST_ADD_TASK ==
            requestCode && Activity.RESULT_OK == resultCode
        ) {
            tasksView.showSuccessfullySavedMessage()
            tasksRepository.refreshTasks()
        }
    }

    override fun loadTasks(forceUpdate: Boolean) {
        // Simplification for sample: a network reload will be forced on first load.
        loadTasks(forceUpdate || firstLoad, true)
        firstLoad = false
    }

    /**
     * @param forceUpdate   Pass in true to refresh the data in the [TasksDataSource]
     * *
     * @param showLoadingUI Pass in true to display a loading icon in the UI
     */
    private fun loadTasks(forceUpdate: Boolean, showLoadingUI: Boolean) {
        if (showLoadingUI) {
            tasksView.setLoadingIndicator(true)
        }
        if (forceUpdate) {
            tasksRepository.refreshTasks()
        }

        // The network request might be handled in a different thread so make sure Espresso knows
        // that the app is busy until the response is handled.
        EspressoIdlingResource.increment() // App is busy until further notice

        tasksRepository.getTasks(object : TasksDataSource.LoadTasksCallback {
            override fun onTasksLoaded(tasks: List<Task>) {
                val tasksToShow = ArrayList<Task>()

                // This callback may be called twice, once for the cache and once for loading
                // the data from the server API, so we check before decrementing, otherwise
                // it throws "Counter has been corrupted!" exception.
                if (!EspressoIdlingResource.countingIdlingResource.isIdleNow) {
                    EspressoIdlingResource.decrement() // Set app as idle.

                }

                // We filter the tasks based on the requestType
                for (task in tasks) {
                    when (currentFiltering) {
                        TasksFilterType.ALL_TASKS ->if (!task.isRemoved) tasksToShow.add(task)
                        TasksFilterType.ACTIVE_TASKS -> if (task.isActive&&!task.isRemoved&&!task.isCanceled&&!task.isOld) { tasksToShow.add(task) }
                        TasksFilterType.DELETED_TASKS -> if (task.isRemoved) { tasksToShow.add(task) }
                        TasksFilterType.CANCELED -> if (task.isCanceled) { tasksToShow.add(task) }
                        TasksFilterType.HISTORY -> if (task.isOld&&!task.isRemoved) { tasksToShow.add(task) }
                        TasksFilterType.COMPLETED_TASKS -> if (task.isCompleted&&!task.isRemoved) { tasksToShow.add(task) }
                    }
                }
                // The view may not be able to handle UI updates anymore
                if (!tasksView.isActive) {
                    return
                }

                if (showLoadingUI) {
                    tasksView.setLoadingIndicator(false)
                }

                processTasks(tasksToShow)
            }

            override fun onDataNotAvailable() {
                // The view may not be able to handle UI updates anymore
                if (!tasksView.isActive) {
                    return
                }
                tasksView.showLoadingTasksError()
            }
        })
    }

    private fun processTasks(tasks: List<Task>) {
        if (tasks.isEmpty()) {
            // Show a message indicating there are no tasks for that filter type.
            processEmptyTasks()
        } else {
            // Show the list of tasks
            tasksView.showTasks(tasks)
            // Set the filter label's text.
            showFilterLabel()
        }
    }

    private fun showFilterLabel() {
        when (currentFiltering) {
            TasksFilterType.ACTIVE_TASKS -> tasksView.showActiveFilterLabel()
            TasksFilterType.COMPLETED_TASKS -> tasksView.showCompletedFilterLabel()
            TasksFilterType.DELETED_TASKS -> tasksView.showDeletedFilterLabel()
            TasksFilterType.HISTORY -> tasksView.showHistoryFilterLabel()
            else -> tasksView.showAllFilterLabel()
        }
    }

    private fun processEmptyTasks() {
        when (currentFiltering) {
            TasksFilterType.ACTIVE_TASKS -> tasksView.showNoActiveTasks()
            TasksFilterType.COMPLETED_TASKS -> tasksView.showNoCompletedTasks()
            TasksFilterType.DELETED_TASKS -> tasksView.showNoCompletedTasks()
            else -> tasksView.showNoTasks()
        }
    }

    override fun addNewTask() {
        tasksView.showAddTask()
    }

    override fun openTaskDetails(requestedTask: Task) {
        tasksView.showTaskDetailsUi(requestedTask.id)
    }

    override fun openEditTask(requestedTask: Task) {
//        if (edit == "edit")
            tasksView.showEditTask(requestedTask.id)
//        else
//            removeTask(requestedTask)
    }
    override fun removeTask(removedTask: Task){
        tasksRepository.removeTask(removedTask)
        tasksView.showTaskDeleted()
        loadTasks(false, false)
    }

    override fun deleteTask(deletedTask: Task) {
        val taskDetailView = TaskDetailFragment()
        if (deletedTask.id.isEmpty()) {
            taskDetailView.showMissingTask()
            return
        }
        tasksRepository.deleteTask(deletedTask.id)
        tasksView.showTaskDeleted()
        loadTasks(false, false)
    }

    override fun completeTask(completedTask: Task) {
        tasksRepository.completeTask(completedTask)
        tasksView.showTaskMarkedComplete()
        loadTasks(false, false)
    }

    override fun cancelTask(completedTask: Task) {
        tasksRepository.cancelTask(completedTask)
        tasksView.showTaskCanceled()
        loadTasks(false, false)    }

    override fun oldTask(completedTask: Task) {
        tasksRepository.oldTask(completedTask)
//        tasksView.showTaskMarkedComplete()
        loadTasks(false, false)    }

    override fun activateTask(activeTask: Task) {
        tasksRepository.activateTask(activeTask)
        tasksView.showTaskMarkedActive()
        loadTasks(false, false)
    }

    override fun clearCompletedTasks() {
        tasksRepository.clearCompletedTasks()
        tasksView.showCompletedTasksCleared()
        loadTasks(false, false)
    }

}