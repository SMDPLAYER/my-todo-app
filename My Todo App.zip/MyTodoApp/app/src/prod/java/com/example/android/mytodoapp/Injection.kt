package com.example.android.mytodoapp

//import android.content.Context
//import com.example.android.mytodoapp.mock.FakeTasksRemoteDataSource
//import com.example.android.mytodoapp.data.source.TasksRepository
//import com.example.android.mytodoapp.data.source.TasksDataSource
//import com.example.android.mytodoapp.data.source.local.TasksLocalDataSource
//import com.example.android.mytodoapp.data.source.local.ToDoDatabase
//import com.example.android.mytodoapp.utils.AppExecutors
///**
// * Enables injection of mock implementations for
// * [TasksDataSource] at compile time. This is useful for testing, since it allows us to use
// * a fake instance of the class to isolate the dependencies and run a test hermetically.
// */
//object Injection {
//    fun provideTasksRepository(context: Context): TasksRepository {
//        val database = ToDoDatabase.getInstance(context)
//        return TasksRepository.getInstance(TasksRemoteDataSource,
//            TasksLocalDataSource.getInstance(AppExecutors(), database.taskDao()))
//    }
//}