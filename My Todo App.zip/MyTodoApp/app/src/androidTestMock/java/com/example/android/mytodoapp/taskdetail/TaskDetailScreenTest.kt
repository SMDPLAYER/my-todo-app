
package com.example.android.mytodoapp.taskdetail

/**
 * Tests for the tasks screen, the main screen which contains a list of all tasks.
/*
 *//*

@RunWith(AndroidJUnit4::class) @LargeTest class TaskDetailScreenTest {

    private val TASK_TITLE = "ATSL"

    private val TASK_DESCRIPTION = "Rocks"

    */
/**
     * [Task] stub that is added to the fake service API layer.
     *//*

    private val ACTIVE_TASK = Task(TASK_TITLE, TASK_DESCRIPTION).apply { isCompleted = false }

    */
/**
     * [Task] stub that is added to the fake service API layer.
     *//*

    private val COMPLETED_TASK = Task(TASK_TITLE, TASK_DESCRIPTION).apply { isCompleted = true }

    */
/**
     * [ActivityTestRule] is a JUnit [@Rule][Rule] to launch your activity under test.

     *
     *
     * Rules are interceptors which are executed for each test method and are important building
     * blocks of Junit tests.

     *
     *
     * Sometimes an [Activity] requires a custom start [Intent] to receive data
     * from the source Activity. ActivityTestRule has a feature which let's you lazily start the
     * Activity under test, so you can control the Intent that is used to start the target Activity.
     *//*

    @Rule @JvmField var taskDetailActivityTestRule =
        ActivityTestRule(TaskDetailActivity::class.java, */
/* Initial touch mode  *//*
 true,
            */
/* Lazily launch activity *//*
 false)

    private fun loadActiveTask() {
        startActivityWithWithStubbedTask(ACTIVE_TASK)
    }

    private fun loadCompletedTask() {
        startActivityWithWithStubbedTask(COMPLETED_TASK)
    }

    */
/**
     * Setup your test fixture with a fake task id. The [TaskDetailActivity] is started with
     * a particular task id, which is then loaded from the service API.

     *
     *
     * Note that this test runs hermetically and is fully isolated using a fake implementation of
     * the service API. This is a great way to make your tests more reliable and faster at the same
     * time, since they are isolated from any outside dependencies.
     *//*

    private fun startActivityWithWithStubbedTask(task: Task) {
        // Add a task stub to the fake service api layer.
        TasksRepository.destroyInstance()
        FakeTasksRemoteDataSource.getInstance().addTasks(task)

        // Lazily start the Activity from the ActivityTestRule this time to inject the start Intent
        val startIntent = Intent().apply { putExtra(TaskDetailActivity.EXTRA_TASK_ID, task.id) }
        taskDetailActivityTestRule.launchActivity(startIntent)
    }

    @Test fun activeTaskDetails_DisplayedInUi() {
        loadActiveTask()

        // Check that the task title and description are displayed
        onView(withId(R.id.task_detail_title)).check(matches(withText(TASK_TITLE)))
        onView(withId(R.id.task_detail_description)).check(matches(withText(TASK_DESCRIPTION)))
        onView(withId(R.id.task_detail_complete)).check(matches(not(isChecked())))
    }

    @Test fun completedTaskDetails_DisplayedInUi() {
        loadCompletedTask()

        // Check that the task title and description are displayed
        onView(withId(R.id.task_detail_title)).check(matches(withText(TASK_TITLE)))
        onView(withId(R.id.task_detail_description)).check(matches(withText(TASK_DESCRIPTION)))
        onView(withId(R.id.task_detail_complete)).check(matches(isChecked()))
    }

    @Test fun orientationChange_menuAndTaskPersist() {
        loadActiveTask()

        // Check delete menu item is displayed and is unique
        onView(withId(R.id.menu_delete)).check(matches(isDisplayed()))

        TestUtils.rotateOrientation(taskDetailActivityTestRule.activity)

        // Check that the task is shown
        onView(withId(R.id.task_detail_title)).check(matches(withText(TASK_TITLE)))
        onView(withId(R.id.task_detail_description)).check(matches(withText(TASK_DESCRIPTION)))

        // Check delete menu item is displayed and is unique
        onView(withId(R.id.menu_delete)).check(matches(isDisplayed()))
    }

}
*/